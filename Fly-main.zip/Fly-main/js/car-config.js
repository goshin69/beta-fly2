//Variable json para definir los modelos de los carros

const carModel=[
   {
    id:"car1",
    url:"urlRaw",
    color:"",
    nDoors:"",
    typeCar:"",
    velocity:"",
    aceleration:"",
    description:""
   }

]